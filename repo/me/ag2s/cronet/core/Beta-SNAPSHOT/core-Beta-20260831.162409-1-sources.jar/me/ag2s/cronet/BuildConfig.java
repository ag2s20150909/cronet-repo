/**
 * Automatically generated file. DO NOT MODIFY
 */
package me.ag2s.cronet;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "me.ag2s.cronet";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String Cronet_Version = "153.0.8010.18";
  // Field from default config.
  public static final boolean includeCronetSo = false;
}
